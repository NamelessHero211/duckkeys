import UIKit
import AVFoundation
import AudioToolbox

final class KeyboardViewController: UIInputViewController, UIInputViewAudioFeedback {
    var enableInputClicksWhenVisible: Bool { true }
    private let background = UIColor(red: 0.72, green: 0.81, blue: 0.87, alpha: 1)
    private let keyColor = UIColor(red: 0.95, green: 0.97, blue: 0.99, alpha: 1)
    private let accent = UIColor(red: 0.07, green: 0.47, blue: 0.82, alpha: 1)
    private var prefs = DuckKeysConfig.preference
    private var stack = UIStackView()
    private var suggestionRow = UIStackView()
    private var suggestionButtons: [UIButton] = []
    private var statusLabel = UILabel()
    private var soundButton = UIButton(type: .system)
    private var shift = false
    private var capsLock = false
    private var symbols = false
    private var emoji = false
    private var translationMode = false
    private var translationSource = "en"
    private var translationTarget = "es"
    private var translationDraft = ""
    private var translationResult = ""
    private var translationWork: DispatchWorkItem?
    private var translationRequest = 0
    private var suggestionWork: DispatchWorkItem?
    private var suggestionRevision = 0
    private var dictionary: [String] = []
    private var dictionarySet = Set<String>()
    private var prefixIndex: [String: [String]] = [:]
    private var players: [String: AVAudioPlayer] = [:]
    private var lastShiftTap: TimeInterval = 0
    private var buttons: [UIButton] = []
    private let languages = [("en", "English"), ("es", "Spanish"), ("fr", "French"), ("de", "German"), ("it", "Italian"), ("pt", "Portuguese"), ("ru", "Russian"), ("ja", "Japanese"), ("ko", "Korean"), ("zh", "Chinese"), ("ar", "Arabic"), ("hi", "Hindi")]

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = background
        view.isMultipleTouchEnabled = true
        buildKeyboard()
        preloadSounds()
        loadDictionary()
        setHeight(296)
        refreshSuggestions()
    }
    override func viewWillAppear(_ animated: Bool) { super.viewWillAppear(animated); updateSoundIcon() }
    private func setHeight(_ value: CGFloat) {
        let c = view.heightAnchor.constraint(equalToConstant: value); c.priority = .defaultHigh; c.isActive = true
    }
    private func buildKeyboard() {
        stack.axis = .vertical; stack.spacing = 5; stack.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(stack)
        NSLayoutConstraint.activate([stack.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 4), stack.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -4), stack.topAnchor.constraint(equalTo: view.topAnchor, constant: 5), stack.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -7)])
        let bar = UIStackView(); bar.axis = .horizontal; bar.alignment = .center; bar.distribution = .fill; bar.spacing = 5
        soundButton.setTitle("🔊", for: .normal); soundButton.accessibilityLabel = "Squeak volume and sound"; soundButton.addTarget(self, action: #selector(toggleSound), for: .touchUpInside); bar.addArrangedSubview(soundButton)
        statusLabel.text = "Duck Keys"; statusLabel.font = .systemFont(ofSize: 12); statusLabel.textColor = .darkGray; statusLabel.textAlignment = .center; statusLabel.lineBreakMode = .byTruncatingTail; bar.addArrangedSubview(statusLabel); statusLabel.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)
        let translate = utility("Tr", #selector(toggleTranslation)); bar.addArrangedSubview(translate)
        let languages = utility("English ⇄ Spanish", #selector(swapLanguages)); bar.addArrangedSubview(languages)
        stack.addArrangedSubview(bar)
        suggestionRow.axis = .horizontal; suggestionRow.distribution = .fillEqually; suggestionRow.spacing = 3
        for _ in 0..<3 { let b = UIButton(type: .system); b.setTitle("", for: .normal); b.setTitleColor(.darkText, for: .normal); b.titleLabel?.font = .systemFont(ofSize: 14); b.addTarget(self, action: #selector(chooseSuggestion(_:)), for: .touchUpInside); suggestionButtons.append(b); suggestionRow.addArrangedSubview(b) }
        stack.addArrangedSubview(suggestionRow)
        addLetters(["qwertyuiop"]); addLetters(["asdfghjkl"])
        let third = UIStackView(); third.axis = .horizontal; third.distribution = .fillEqually; third.spacing = 4
        let shiftKey = utility("⇧", #selector(toggleShift)); third.addArrangedSubview(shiftKey)
        for letter in "zxcvbnm" { third.addArrangedSubview(characterKey(String(letter))) }
        third.addArrangedSubview(utility("⌫", #selector(backspace), wide: true)); stack.addArrangedSubview(third)
        let bottom = UIStackView(); bottom.axis = .horizontal; bottom.distribution = .fill; bottom.spacing = 4
        bottom.addArrangedSubview(utility(symbols ? "ABC" : "?123", #selector(toggleSymbols), wide: true))
        bottom.addArrangedSubview(utility(emoji ? "ABC" : "☺︎", #selector(toggleEmoji), wide: true))
        let space = characterKey("space"); space.accessibilityIdentifier = "space"; space.setContentHuggingPriority(.defaultLow, for: .horizontal); bottom.addArrangedSubview(space)
        bottom.addArrangedSubview(characterKey(".")); bottom.addArrangedSubview(utility("↵", #selector(enter), wide: true)); bottom.addArrangedSubview(utility("🌐", #selector(nextKeyboard), wide: true)); stack.addArrangedSubview(bottom)
    }
    private func addLetters(_ rows: [String]) {
        for row in rows { let line = UIStackView(); line.axis = .horizontal; line.distribution = .fillEqually; line.spacing = 4; for c in row { line.addArrangedSubview(characterKey(String(c))) }; stack.addArrangedSubview(line) }
    }
    private func characterKey(_ value: String) -> UIButton {
        let key = UIButton(type: .system); key.backgroundColor = keyColor; key.layer.cornerRadius = 5; key.setTitle(value == "space" ? "space" : value, for: .normal); key.setTitleColor(.darkText, for: .normal); key.titleLabel?.font = .systemFont(ofSize: value == "space" ? 17 : 22); key.multipleTouchEnabled = true; key.isExclusiveTouch = false; key.addTarget(self, action: #selector(keyPress(_:)), for: .touchDown); key.accessibilityIdentifier = value; buttons.append(key); return key
    }
    private func utility(_ title: String, _ action: Selector, wide: Bool = false) -> UIButton {
        let key = UIButton(type: .system); key.backgroundColor = wide ? UIColor(red: 0.83, green: 0.88, blue: 0.96, alpha: 1) : keyColor; key.layer.cornerRadius = wide ? 9 : 6; key.setTitle(title, for: .normal); key.setTitleColor(.darkText, for: .normal); key.titleLabel?.font = .systemFont(ofSize: wide ? 16 : 13, weight: .medium); key.addTarget(self, action: action, for: .touchUpInside); return key
    }
    private func preloadSounds() {
        for name in Set(DuckKeysConfig.resourceForChoice) {
            guard let url = Bundle.main.url(forResource: name, withExtension: "wav"), let player = try? AVAudioPlayer(contentsOf: url) else { continue }
            player.prepareToPlay(); players[name] = player
        }
    }
    private func loadDictionary() {
        DispatchQueue.global(qos: .utility).async {
            guard let url = Bundle.main.url(forResource: "English-dictionary", withExtension: "txt"), let text = try? String(contentsOf: url, encoding: .utf8) else { return }
            var words: [String] = []; var index: [String: [String]] = [:]
            for line in text.split(whereSeparator: \.isNewline) {
                guard let word = line.split(separator: " ").first else { continue }; let s = String(word).lowercased(); words.append(s)
                for n in 1...min(5, s.count) { let p = String(s.prefix(n)); if (index[p]?.count ?? 0) < 8 { index[p, default: []].append(s) } }
            }
            DispatchQueue.main.async { self.dictionary = words; self.dictionarySet = Set(words); self.prefixIndex = index; self.refreshSuggestions() }
        }
    }
    @objc private func keyPress(_ sender: UIButton) {
        let id = sender.accessibilityIdentifier ?? ""
        if translationMode { typeTranslation(id == "space" ? " " : displayed(id)); return }
        let value = id == "space" ? " " : displayed(id)
        if value == " " { applyAutocorrectBeforeSpace() }
        textDocumentProxy.insertText(value)
        if !capsLock && shift { shift = false; updateLetterCase() }
        click(); refreshSuggestions()
    }
    private func displayed(_ value: String) -> String { value.count == 1 && value.rangeOfCharacter(from: .letters) != nil && (shift || capsLock) ? value.uppercased() : value }
    private func click() {
        if prefs.bool(forKey: "haptics") { UIImpactFeedbackGenerator(style: .light).impactOccurred() }
        guard prefs.bool(forKey: "soundEnabled"), prefs.double(forKey: "soundVolume") > 0 else { UIDevice.current.playInputClick(); return }
        guard hasFullAccess else { UIDevice.current.playInputClick(); return }
        let choice = min(8, max(0, prefs.integer(forKey: "soundIndex")))
        let actual = choice == 5 ? Int.random(in: 0...4) : choice
        let name = DuckKeysConfig.resourceForChoice[actual]
        if let player = players[name] { player.stop(); player.currentTime = 0; player.volume = Float(min(1, max(0, prefs.double(forKey: "soundVolume")))); player.play() }
        else { UIDevice.current.playInputClick() }
    }
    private func applyAutocorrectBeforeSpace() {
        guard prefs.bool(forKey: "autocorrect"), let before = textDocumentProxy.documentContextBeforeInput else { return }
        let word = before.split(whereSeparator: { $0.isWhitespace }).last.map(String.init) ?? ""; guard word.count >= 3, word.rangeOfCharacter(from: .letters.inverted) == nil else { return }
        let checker = UITextChecker(); let range = NSRange(location: 0, length: (word as NSString).length)
        guard checker.rangeOfMisspelledWord(in: word, range: range, startingAt: 0, wrap: false, language: "en_US").location != NSNotFound,
              let guess = checker.guesses(forWordRange: range, in: word, language: "en_US")?.first, dictionarySet.contains(guess.lowercased()) else { return }
        for _ in 0..<word.count { textDocumentProxy.deleteBackward() }; textDocumentProxy.insertText(guess)
    }
    private func refreshSuggestions() {
        guard !translationMode else { suggestionButtons.forEach { $0.setTitle("", for: .normal) }; return }
        suggestionWork?.cancel(); suggestionRevision += 1; let token = suggestionRevision
        let before = textDocumentProxy.documentContextBeforeInput ?? ""
        let word = (before.split(whereSeparator: { $0.isWhitespace }).last.map(String.init) ?? "").lowercased()
        guard word.count >= 1, word.rangeOfCharacter(from: .letters.inverted) == nil else { suggestionButtons.forEach { $0.setTitle("", for: .normal) }; return }
        let work = DispatchWorkItem { [weak self] in
            guard let self else { return }
            var values = Array((self.prefixIndex[String(word.prefix(min(5, word.count)))] ?? []).filter { $0 != word && $0.hasPrefix(word) }.prefix(3))
            if values.isEmpty { let range = NSRange(location: 0, length: (word as NSString).length); values = Array((UITextChecker().guesses(forWordRange: range, in: word, language: "en_US") ?? []).prefix(3)) }
            DispatchQueue.main.async { guard token == self.suggestionRevision, !self.translationMode else { return }; for (i, b) in self.suggestionButtons.enumerated() { b.setTitle(i < values.count ? values[i] : "", for: .normal) } }
        }
        suggestionWork = work; DispatchQueue.global(qos: .utility).asyncAfter(deadline: .now() + .milliseconds(90), execute: work)
    }
    @objc private func chooseSuggestion(_ sender: UIButton) {
        guard let value = sender.title(for: .normal), !value.isEmpty else { return }
        let before = textDocumentProxy.documentContextBeforeInput ?? ""; let word = before.split(whereSeparator: { $0.isWhitespace }).last.map(String.init) ?? ""
        for _ in 0..<word.count { textDocumentProxy.deleteBackward() }; textDocumentProxy.insertText(value + " "); click(); refreshSuggestions()
    }
    @objc private func toggleShift() { let now = Date.timeIntervalSinceReferenceDate; if now - lastShiftTap < 0.45 { capsLock.toggle(); shift = capsLock } else { shift.toggle() }; lastShiftTap = now; updateLetterCase(); click() }
    private func updateLetterCase() { for b in buttons { guard let id = b.accessibilityIdentifier, id.count == 1, id.rangeOfCharacter(from: .letters) != nil else { continue }; b.setTitle((shift || capsLock) ? id.uppercased() : id.lowercased(), for: .normal) } }
    @objc private func toggleSymbols() { symbols.toggle(); emoji = false; updateKeyRows(); click() }
    @objc private func toggleEmoji() { emoji.toggle(); symbols = false; updateKeyRows(); click() }
    private func updateKeyRows() {
        let letters = emoji ? ["😀😃😄😁😆😅😂🙂😍🥰", "😉😊😎😭😢🤔🙃🤗😴"] : symbols ? ["1234567890", "@#$%&-*+()"] : ["qwertyuiop", "asdfghjkl"]
        for (rowIndex, row) in stack.arrangedSubviews.enumerated() where rowIndex == 2 || rowIndex == 3 {
            guard let line = row as? UIStackView else { continue }; while line.arrangedSubviews.count > 0 { let v = line.arrangedSubviews[0]; line.removeArrangedSubview(v); v.removeFromSuperview() }
            for character in letters[rowIndex - 2] { line.addArrangedSubview(characterKey(String(character))) }
        }
    }
    @objc private func backspace() { if translationMode { if !translationDraft.isEmpty { translationDraft.removeLast(); translateDebounced() } } else { textDocumentProxy.deleteBackward(); refreshSuggestions() }; click() }
    @objc private func enter() { if translationMode { finishTranslation() } else { textDocumentProxy.insertText("\n"); refreshSuggestions() }; click() }
    @objc private func nextKeyboard() { advanceToNextInputMode() }
    @objc private func toggleSound() { let value = prefs.bool(forKey: "soundEnabled"); prefs.set(!value, forKey: "soundEnabled"); updateSoundIcon() }
    private func updateSoundIcon() { soundButton.setTitle(prefs.bool(forKey: "soundEnabled") ? "🔊" : "🔇", for: .normal) }
    @objc private func toggleTranslation() {
        guard hasFullAccess else { statusLabel.text = "Enable Allow Full Access in Settings to use Yandex"; return }
        translationMode.toggle(); translationDraft = ""; translationResult = ""; statusLabel.text = translationMode ? "Type source phrase · \(languageName(translationSource)) → \(languageName(translationTarget))" : "Duck Keys"; refreshSuggestions()
    }
    @objc private func swapLanguages() {
        if translationMode { swap(&translationSource, &translationTarget); statusLabel.text = "\(languageName(translationSource)) → \(languageName(translationTarget))"; translateDebounced() }
        else { let i = languages.firstIndex { $0.0 == translationSource } ?? 0; translationSource = languages[(i + 1) % languages.count].0; translationTarget = languages[(i + 2) % languages.count].0; statusLabel.text = "\(languageName(translationSource)) ⇄ \(languageName(translationTarget))" }
    }
    private func languageName(_ code: String) -> String { languages.first { $0.0 == code }?.1 ?? code }
    private func typeTranslation(_ value: String) { guard translationDraft.count < 2000 else { statusLabel.text = "Limit 2,000 characters"; return }; translationDraft.append(value); statusLabel.text = translationDraft.isEmpty ? "Type source phrase" : String(translationDraft.suffix(36)); translateDebounced(); click() }
    private func translateDebounced() {
        translationWork?.cancel(); translationRequest += 1; let token = translationRequest; let source = translationDraft
        guard !source.isEmpty else { return }
        guard DuckKeysConfig.apiKey() != nil else { statusLabel.text = "Save Yandex API key in Duck Keys app"; return }
        let work = DispatchWorkItem { [weak self] in self?.sendTranslation(source, token: token) }
        translationWork = work; DispatchQueue.main.asyncAfter(deadline: .now() + .milliseconds(250), execute: work)
    }
    private func sendTranslation(_ source: String, token: Int) {
        guard let key = DuckKeysConfig.apiKey(), let url = URL(string: "https://translate.api.cloud.yandex.net/translate/v2/translate") else { statusLabel.text = "Yandex setup required"; return }
        var request = URLRequest(url: url); request.httpMethod = "POST"; request.timeoutInterval = 12; request.setValue("application/json", forHTTPHeaderField: "Content-Type"); request.setValue("Api-Key \(key)", forHTTPHeaderField: "Authorization")
        var body: [String: Any] = ["targetLanguageCode": translationTarget, "format": "PLAIN_TEXT", "texts": [source]]; body["sourceLanguageCode"] = translationSource; request.httpBody = try? JSONSerialization.data(withJSONObject: body)
        URLSession.shared.dataTask(with: request) { [weak self] data, response, error in
            DispatchQueue.main.async {
                guard let self, self.translationRequest == token, self.translationDraft == source else { return }
                if error != nil { self.statusLabel.text = "Yandex connection failed · Retry by typing"; return }
                guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode), let data,
                      let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any], let first = (json["translations"] as? [[String: Any]])?.first, let text = first["text"] as? String else { self.statusLabel.text = "Check Yandex key and translation access"; return }
                self.translationResult = text; self.statusLabel.text = String(text.suffix(42))
            }
        }.resume()
    }
    private func finishTranslation() {
        translationWork?.cancel(); if !translationResult.isEmpty { textDocumentProxy.insertText(translationResult + " ") }
        translationMode = false; translationDraft = ""; translationResult = ""; statusLabel.text = "Duck Keys"; refreshSuggestions()
    }
}
