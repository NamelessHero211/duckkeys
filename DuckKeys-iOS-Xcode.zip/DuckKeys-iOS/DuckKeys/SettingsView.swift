import SwiftUI
import AVFoundation
import UIKit

struct SettingsView: View {
    @AppStorage("soundIndex", store: DuckKeysConfig.preference) private var soundIndex = 0
    @AppStorage("soundEnabled", store: DuckKeysConfig.preference) private var soundEnabled = true
    @AppStorage("soundVolume", store: DuckKeysConfig.preference) private var soundVolume = 0.65
    @AppStorage("autocorrect", store: DuckKeysConfig.preference) private var autocorrect = true
    @AppStorage("haptics", store: DuckKeysConfig.preference) private var haptics = true
    @State private var apiKey = ""
    @State private var saved = DuckKeysConfig.apiKey() != nil
    @State private var status = ""
    @State private var testText = ""
    @State private var player: AVAudioPlayer?
    private let ink = Color(red: 0.08, green: 0.24, blue: 0.25)

    var body: some View {
        NavigationStack {
            Form {
                Section("Set up Duck Keys") {
                    Label("1. Open Settings → General → Keyboard → Keyboards → Add New Keyboard.", systemImage: "keyboard")
                    Label("2. Choose Duck Keys, then Allow Full Access for squeak audio, shared settings, and optional Yandex translation.", systemImage: "hand.tap")
                    Text("Apple custom keyboards cannot access the microphone. Use the iPhone’s built-in Dictation from the globe/dictation controls instead.").font(.footnote).foregroundStyle(.secondary)
                }
                Section("Typing sounds") {
                    Picker("Squeak", selection: $soundIndex) {
                        ForEach(DuckKeysConfig.soundNames.indices, id: \.self) { i in Text(DuckKeysConfig.soundNames[i]).tag(i) }
                    }
                    Toggle("Typing squeaks", isOn: $soundEnabled)
                    VStack(alignment: .leading) {
                        Text("Duck Keys volume · \(Int(soundVolume * 100))%")
                        Slider(value: $soundVolume, in: 0...1).tint(ink)
                        Text("This adjusts the squeak level in Duck Keys. iOS system volume and mute still apply.").font(.footnote).foregroundStyle(.secondary)
                    }
                    Button(action: preview) { Label("Preview selected squeak", systemImage: "speaker.wave.2") }
                }
                Section("Typing") {
                    Toggle("Auto-correct", isOn: $autocorrect)
                    Toggle("Key vibration", isOn: $haptics)
                }
                Section("Yandex live translation") {
                    SecureField("Yandex Cloud API key", text: $apiKey).textInputAutocapitalization(.never).autocorrectionDisabled()
                    HStack {
                        Button(saved ? "Replace API key" : "Save API key") { saveKey() }
                            .disabled(apiKey.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                        if saved { Button("Remove", role: .destructive) { DuckKeysConfig.deleteAPIKey(); saved = false; apiKey = ""; status = "API key removed." } }
                    }
                    Text(status.isEmpty ? "Translation sends text only after you turn on Tr in the keyboard. The key is stored in Keychain. Yandex Cloud may charge for use." : status)
                        .font(.footnote).foregroundStyle(.secondary)
                }
                Section("Try it") {
                    TextField("Type here to test Duck Keys", text: $testText).textInputAutocapitalization(.sentences)
                    Text("Install and select the keyboard, then use the globe key to switch to Duck Keys in any app.").font(.footnote).foregroundStyle(.secondary)
                }
                Section { Text("Duck Keys is an independent keyboard. It does not save message text or send keystrokes to our servers. Yandex translation sends the source phrase to Yandex Cloud when translation is enabled.").font(.footnote).foregroundStyle(.secondary) }
            }
            .navigationTitle("Duck Keys")
            .tint(ink)
            .onAppear { saved = DuckKeysConfig.apiKey() != nil }
        }
    }
    private func preview() {
        let index = soundIndex == 5 ? Int.random(in: 0..<5) : soundIndex
        let name = DuckKeysConfig.resourceForChoice[index]
        guard let url = Bundle.main.url(forResource: name, withExtension: "wav") else { status = "Sound file missing: \(name)"; return }
        do { player = try AVAudioPlayer(contentsOf: url); player?.volume = Float(soundVolume); player?.prepareToPlay(); player?.play() }
        catch { status = "Could not preview this sound." }
    }
    private func saveKey() {
        do { try DuckKeysConfig.saveAPIKey(apiKey); saved = true; apiKey = ""; status = "Yandex key saved securely on this device." }
        catch { status = "Could not save the key. Check signing and Keychain sharing in Xcode." }
    }
}
