import SwiftUI

@main
struct DuckKeysApp: App {
    var body: some Scene { WindowGroup { SettingsView() } }
}
