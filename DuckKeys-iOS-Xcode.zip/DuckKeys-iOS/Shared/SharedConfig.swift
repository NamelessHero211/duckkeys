import Foundation
import Security

struct DuckKeysConfig {
    static let appGroup = "group.com.namelesshero.duckkeys"
    static var keychainGroup: String {
        let prefix = (Bundle.main.infoDictionary?["AppIdentifierPrefix"] as? String)?.trimmingCharacters(in: CharacterSet(charactersIn: ".")) ?? ""
        return prefix.isEmpty ? "com.namelesshero.duckkeys.shared" : "\(prefix).com.namelesshero.duckkeys.shared"
    }
    static let preference: UserDefaults = {
        let defaults = UserDefaults(suiteName: appGroup) ?? .standard
        defaults.register(defaults: ["soundIndex": 0, "soundEnabled": true, "soundVolume": 0.65, "autocorrect": true, "haptics": true])
        return defaults
    }()
    static let soundNames = ["Classic rubber duck", "Tiny duckling", "Deep bath duck", "Double squeak", "Wobbly duck", "Surprise me", "High-pitched dog toy", "Video duck squeak", "Uwu (video)"]
    static let resourceForChoice = ["duck0", "duck1", "duck2", "duck3", "duck4", "duck0", "duck5", "duck6", "uwu"]

    static func apiKey() -> String? {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: "DuckKeys.Yandex", kSecAttrAccount as String: "translation-api-key", kSecReturnData as String: true, kSecMatchLimit as String: kSecMatchLimitOne, kSecAttrAccessGroup as String: keychainGroup]
        var item: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &item) == errSecSuccess, let data = item as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }
    static func saveAPIKey(_ value: String) throws {
        let key = value.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !key.isEmpty, !key.contains("\n"), !key.contains("\r") else { throw KeyError.invalid }
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: "DuckKeys.Yandex", kSecAttrAccount as String: "translation-api-key", kSecAttrAccessGroup as String: keychainGroup]
        SecItemDelete(query as CFDictionary)
        var insert = query
        insert[kSecValueData as String] = Data(key.utf8)
        insert[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        let result = SecItemAdd(insert as CFDictionary, nil)
        guard result == errSecSuccess else { throw KeyError.keychain(result) }
    }
    static func deleteAPIKey() {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: "DuckKeys.Yandex", kSecAttrAccount as String: "translation-api-key", kSecAttrAccessGroup as String: keychainGroup]
        SecItemDelete(query as CFDictionary)
    }
    enum KeyError: Error { case invalid, keychain(OSStatus) }
}
