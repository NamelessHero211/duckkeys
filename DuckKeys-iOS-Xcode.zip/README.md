# Duck Keys for iOS — Xcode project

This is a native iOS containing app plus a systemwide Custom Keyboard extension. It carries over the selectable Duck Keys samples, the independent in-app sound level, haptics, English suggestions/autocorrection, and the optional Yandex live-translation bar. Character keys insert on touch-down for a quicker feel; the buttons accept multiple simultaneous touches.

## Important iOS limits

- iOS custom keyboard extensions cannot access the microphone. Duck Keys iOS therefore cannot provide its Android speech-to-text button. Test speech input with Apple's built-in Dictation keyboard control.
- Duck Keys requests **Allow Full Access** because its keyboard plays the bundled sounds, shares its preferences/keychain item with the app, and can make Yandex requests. The extension only sends source text to Yandex after the user turns on `Tr`. Keyboard text and suggestions otherwise stay on-device.
- The app's sound slider scales the samples. The iPhone's system volume, mute switch, and audio route remain in control of actual output.
- This Windows workspace has no macOS/Xcode toolchain, Apple signing team, or App Store Connect upload session. The Xcode project has not been compiled on an Apple SDK and no TestFlight build has been uploaded.

## Optional: prepare locally with Xcode

1. Open `DuckKeys.xcodeproj` with Xcode 15 or later. In Signing & Capabilities, choose your Apple Developer team for both targets.
2. Register the App Group `group.com.namelesshero.duckkeys` and the shared Keychain access group `$(AppIdentifierPrefix)com.namelesshero.duckkeys.shared` for that team. If the bundle IDs are already in use, change `com.namelesshero.duckkeys` and its `.keyboard` extension identifier consistently.
3. Build and run the Duck Keys app on an iPhone. Add the keyboard under **Settings → General → Keyboard → Keyboards → Add New Keyboard**, select Duck Keys, and enable **Allow Full Access**.
4. Exercise the keyboard in a test field: rapid taps, two fingers at once, autocorrect, key sounds/volume, and Yandex after adding your own API key in the app. Dictation must use Apple's keyboard.
5. For TestFlight, select the Duck Keys app scheme, set a unique build number, archive for iOS, and upload the signed archive to an App Store Connect app record. Apple Developer Program membership and an App Store Connect role that can upload builds are required. Complete the TestFlight beta information before inviting testers.

## Build and upload without owning a Mac

The included `codemagic.yaml` is a cloud macOS build workflow. Put the contents of this folder at the root of a GitHub repository, connect that repository to Codemagic, and configure an App Store Connect API key integration named `DuckKeysAppStoreConnect` with App Manager access. Then use Codemagic's signing identities to generate an Apple Distribution certificate and fetch App Store provisioning profiles for both `com.namelesshero.duckkeys` and `com.namelesshero.duckkeys.keyboard`. The workflow builds the `DuckKeys` Xcode scheme on a hosted Mac and uploads the IPA to App Store Connect. No local Mac is needed.

The App Store Connect record already exists. The first uploaded build still needs to finish Apple's processing. To let people outside your App Store Connect team test it, complete the TestFlight test information, create an external tester group, and submit the build for TestFlight App Review. Internal testers can be added without external beta review.

The App Store app record, signing identity, and API key are intentionally not included. Sound files and the English word list retain the original assets and attribution; see `Resources/LICENSE-Dictionary.txt`.

## Faster key response

Letter and space keys insert on touch-down, before the finger lifts. Rapid repeated sounds rotate across two prewarmed players per sound so one squeak does not cut off the next. Key haptics reuse a prepared feedback generator. Suggestions are coalesced on a dedicated background queue with a shorter idle delay; text correction stays off the key-down path. The extension remains compatible with iOS 16 and later, including newer Apple OS releases. These changes need a signed build and real-device timing checks on Apple hardware.

